# Qwen3-0.6B：融合实验结束后的 Teacher 蒸馏规划

## 1. 本轮只研究蒸馏

**在融合实验完成后，复用上一阶段的 0.6B Student 和训练数据，新增 HARD、SOFT、HYBRID 三组等量续训。** 本轮不再训练专科，也不再生成融合模型。

要回答的问题是：**对于同一个已经训练好的小模型，继续使用原始数据标签，还是学习 Teacher 概率，能获得更好的效果？原始标签与 Teacher 混合是否更好？**

| 本轮模型 | 监督方式 | 比较目的 |
|---|---|---|
| **`KD_HARD`** | 原始标签 CE | 判断同等额外训练本身的收益 |
| **`KD_SOFT`** | Teacher 概率 KL | 判断只学习 Teacher 是否优于原始标签 |
| **`KD_HYBRID`** | **0.5×CE＋0.5×KL** | 判断两种监督结合是否更好 |

**新增 3 次正式训练。** 上一阶段的 Student 保留为“未做本轮续训”的参照，不直接冒充本轮 HARD 结果。

![蒸馏实验流程](figures/01-experiment-workflow.png)

## 2. 复用什么，需要下载什么

| 项目 | 本轮安排 |
|---|---|
| Student 起点 | 从融合阶段的已有结果中固定 **一个** Qwen3-0.6B checkpoint，三组完全相同 |
| 默认建议 | 使用上一阶段的全数据混合模型；若决定使用某个融合模型，也必须让三组都从它出发 |
| 分类结构 | 继承已有的匹配／不匹配二分类头，不重新随机初始化 |
| Teacher | **`PelaAI/KnowLine-31B-Gen1`**，BF16 权重约 63 GB |
| 训练数据 | 复用上一阶段实际使用的合并训练池及原始标签，不为蒸馏重新扩数据方向 |
| 模型与标签资产 | 已有可用的直接复用；缺失的 Teacher 权重或标注由集群补齐 |
| 环境 | 沿用现有 Student 训练环境；Teacher 用适合其原生概率输出的环境 |

Student 原有权重、分类头和适配结构保持一致；三组使用相同的新 optimizer 与训练配置。**不是 SOFT 从融合模型开始，HARD 却从另一份旧模型开始。**

## 3. 数据与 Teacher 软标签

沿用上一阶段已经准备好的充分训练数据，记为 `D_DISTILL`。保留 Knowledge、Language、Retrieval、Tools、Arts 的来源标记，用于观察蒸馏对各方向的影响，不再重做五个专科的数据建设。

- 三组使用**完全相同的训练文本、候选、顺序和训练量**。
- HARD 使用原始数据标签；SOFT 使用 Teacher 软标签；HYBRID 同时使用二者。
- 复用已有 tokenization 和预处理缓存，不重复处理三遍数据。
- 不把旧 9,998 对准备数据当作正式训练规模上限，也不重新套用 50 万 pair 或两小时限制。

![三组蒸馏训练的数据与监督](figures/02-training-data-matrix.png)

### Teacher 只标一次，三组保持同一输出语义

当前 Student 是匹配／不匹配二分类，因此本轮建议让 Teacher 对每个 pair 输出独立的：

```text
P(匹配)、P(不匹配)
```

使用 Teacher 原生 yes/no 概率，正文与 Student 实际看到的内容一致。**不直接把一道互斥多选题的候选概率，当成各 pair 独立的匹配概率。** 旧标注语义一致时直接复用，否则按本轮二分类目标补标。

Teacher 对 `D_DISTILL` 集中标注并缓存，不在每个 Student step 重新运行 31B。按共享正文批量组织独立问题，减少重复处理；缺少的标注补齐，不单独缩小 SOFT／HYBRID 的训练池，也不只挑 Teacher 答对或高置信度的题。

首轮直接使用 Teacher 原生概率，不额外调整蒸馏温度；Teacher 已折入权重的温度不重复应用。HYBRID 的 Teacher 权重先固定为 **0.5**，不一开始扩成温度和权重网格。

## 4. 续训配置与加速

| 配置项 | 推荐起点 |
|---|---|
| 模型 | 上一阶段固定的同一个 Qwen3-0.6B Student |
| 微调 | 沿用 **LoRA r32、alpha64**，分类头一起训练与保存 |
| 精度 | **BF16** |
| Attention | **causal**；复用现有 FlashAttention／varlen，或现成 SDPA fused attention |
| 单卡 microbatch | **32 pair** |
| 单卡 grad acc | **4** |
| 有效 batch | **128 pair** |
| 学习率 | **5e-5**，作为已经训练好模型的续训起点，三组一致 |
| 优化器 | AdamW、cosine、warmup 3%、weight decay 0.01 |
| 训练长度 | 沿用上一阶段设置，通常为 **4096**；三组相同 |
| 梯度 checkpointing | 显存充足时关闭以减少重算；长序列或显存不足时开启 |
| 训练量 | 先完整训练 `D_DISTILL` **一遍**，三组实际 tokens 一致 |

这里是对已有 Student 续训，不从原始基座重新训练，因此学习率先从 **5e-5** 开始，不直接照搬前一阶段从基座起训的 1e-4。

加速优先使用：**长度分桶＋动态 padding、按 token 预算调整 microbatch、现成 varlen／padding-free packing、预处理缓存和离线软标签缓存。** 动态 microbatch 时累计到实际 128 pair；packing 保留每个 pair 独立的 attention 和分类读出。

资源允许时，三组各用一张空闲卡并行；单卡顺序运行也保持同一预算。Teacher 标注完成后无需继续占用其推理资源。

## 5. 最终比较与图表

沿用上一阶段的同一套五方向、37 项公共 benchmark 和评测方式，不因蒸馏另换输入或删减候选。

| 对象 | Knowledge | Language | Retrieval | Tools | Arts | 公开总分 |
|---|---|---|---|---|---|---|
| 上一阶段 Student | 复用原结果 | 复用原结果 | 复用原结果 | 复用原结果 | 复用原结果 | 复用原结果 |
| HARD 等量续训 | 待测 | 待测 | 待测 | 待测 | 待测 | 待测 |
| SOFT 蒸馏 | 待测 | 待测 | 待测 | 待测 | 待测 | 待测 |
| HYBRID 混合监督 | 待测 | 待测 | 待测 | 待测 | 待测 | 待测 |

核心报告三组差值：

- **SOFT－HARD：**Teacher 软标签相对原始数据标签的收益。
- **HYBRID－HARD：**保留原始标签后，Teacher 的额外价值。
- **各组－起始 Student：**增加本轮训练后，能力实际提升或退化多少。

结果用**四条曲线的五维雷达图、逐 benchmark 差值热力图和总体得分柱状图**展示，同时列出训练耗时、有效 tokens/s 与 Teacher 标注成本。有价值的蒸馏配置再与 HARD 一起补到 **3 个续训 seed**。

Teacher 与 Student 的参数规模不同，可以额外测同硬件推理成本；三组 Student 都是 0.6B，不能仅因采用蒸馏就宣称比 HARD 推理更快。

## 6. 本阶段执行顺序

1. **融合阶段结束后，固定一个 Student 起点和已有训练池。**
2. **复用 Teacher 权重与可用软标签，补齐本轮所需二分类概率。**
3. **从同一 Student 出发，完成 HARD、SOFT、HYBRID 三组等量续训。**
4. **复用原评测，交付三组差值、雷达图和逐项结果。**
5. **有明确收益后，再补匹配 seed，不提前增加新模型或监督网格。**

若完整训练池一遍为 `T` 个实际 tokens，本阶段三个 Student 共新增 **`3T`** 训练 tokens，Teacher 标注成本单列。**不包含重训五个专家、重新训练混合模型起点或再次模型融合。**

相关材料：[Teacher 蒸馏已有证据](../teacher-distillation-evidence-20261030/REPORT.md)。本文仅为融合阶段之后的蒸馏规划，本次不启动集群实验。
